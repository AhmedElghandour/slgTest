cherry-lazy-load
================

WordPress plugin for create blocks with lazy-load effect
